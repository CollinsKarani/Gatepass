-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 04, 2011 at 04:46 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gpms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `variable` varchar(255) NOT NULL,
  `data` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`variable`, `data`) VALUES
('reg_key', '12-580-323');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE IF NOT EXISTS `company` (
  `member_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(100) NOT NULL,
  `company` varchar(100) NOT NULL,
  `reg_no` varchar(100) DEFAULT NULL,
  `address` text,
  `city` varchar(100) DEFAULT NULL,
  `zipcode` varchar(100) DEFAULT NULL,
  `ntn` varchar(100) DEFAULT NULL,
  `ph_no` varchar(100) DEFAULT NULL,
  `fax_no` varchar(100) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `add_info` text,
  PRIMARY KEY (`member_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`member_id`, `user_id`, `company`, `reg_no`, `address`, `city`, `zipcode`, `ntn`, `ph_no`, `fax_no`, `website`, `state`, `country`, `add_info`) VALUES
(1, '1', 'Live Business Management System', NULL, 'Dawood Chourangi\r\nLandhi. Karachi, Pakistan', 'Karachi', NULL, NULL, '0343-3091454 - 021-1231234', NULL, NULL, 'Sindh', 'Pakistan', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `depart`
--

CREATE TABLE IF NOT EXISTS `depart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `depart`
--

INSERT INTO `depart` (`id`, `name`) VALUES
(13, 'new'),
(10, 'Weaving'),
(8, 'Admin'),
(9, 'Dispatch'),
(14, 'IT');

-- --------------------------------------------------------

--
-- Table structure for table `gp_no`
--

CREATE TABLE IF NOT EXISTS `gp_no` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gp_no` varchar(56) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `gp_no`
--


-- --------------------------------------------------------

--
-- Table structure for table `in_non_main`
--

CREATE TABLE IF NOT EXISTS `in_non_main` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ms` varchar(100) NOT NULL,
  `vehicle` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `time` time DEFAULT NULL,
  `depart` varchar(100) NOT NULL,
  `gpno` varchar(100) NOT NULL,
  `sender` varchar(100) NOT NULL,
  `approved` varchar(100) NOT NULL,
  `log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` varchar(16) NOT NULL,
  `address` text,
  `po_no` varchar(255) DEFAULT NULL,
  `return_date` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gpno` (`gpno`),
  UNIQUE KEY `gpno_2` (`gpno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `in_non_main`
--


-- --------------------------------------------------------

--
-- Table structure for table `in_non_sub`
--

CREATE TABLE IF NOT EXISTS `in_non_sub` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gpno` varchar(100) NOT NULL,
  `item` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `ret_date` varchar(16) DEFAULT NULL COMMENT 'Not InUse',
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `in_non_sub`
--


-- --------------------------------------------------------

--
-- Table structure for table `in_ret_main`
--

CREATE TABLE IF NOT EXISTS `in_ret_main` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ms` varchar(100) NOT NULL,
  `vehicle` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `time` time DEFAULT NULL,
  `depart` varchar(100) NOT NULL,
  `gpno` varchar(100) NOT NULL,
  `sender` varchar(100) NOT NULL,
  `approved` varchar(100) NOT NULL,
  `return_date` date NOT NULL,
  `log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` varchar(16) NOT NULL,
  `address` text,
  `po_no` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gpno` (`gpno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `in_ret_main`
--


-- --------------------------------------------------------

--
-- Table structure for table `in_ret_sub`
--

CREATE TABLE IF NOT EXISTS `in_ret_sub` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gpno` varchar(100) NOT NULL,
  `item` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `ret_date` varchar(255) DEFAULT 'No',
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `in_ret_sub`
--


-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE IF NOT EXISTS `location` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `prefix` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`id`, `name`, `prefix`) VALUES
(10, 'Karachi', 'KHI');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `member_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `login` varchar(100) NOT NULL DEFAULT '',
  `passwd` varchar(32) NOT NULL DEFAULT '',
  `type` varchar(36) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`member_id`, `firstname`, `lastname`, `login`, `passwd`, `type`, `location`) VALUES
(11, 'Ayaz', 'Haider', 'admin', '21232f297a57a5a743894a0e4a801fc3', '1', 'Karachi');

-- --------------------------------------------------------

--
-- Table structure for table `ow_gp_ret`
--

CREATE TABLE IF NOT EXISTS `ow_gp_ret` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ms` varchar(100) NOT NULL,
  `vehicle` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `time` time DEFAULT NULL,
  `depart` varchar(100) NOT NULL,
  `gpno` varchar(100) NOT NULL,
  `sender` varchar(100) NOT NULL,
  `approved` varchar(100) NOT NULL,
  `return_date` date NOT NULL,
  `sno1` varchar(255) DEFAULT NULL,
  `item1` varchar(255) DEFAULT NULL,
  `unit1` varchar(255) DEFAULT NULL,
  `qty1` varchar(255) DEFAULT NULL,
  `price1` varchar(255) DEFAULT NULL,
  `remarks1` varchar(255) DEFAULT NULL,
  `sno2` varchar(255) DEFAULT NULL,
  `item2` varchar(255) DEFAULT NULL,
  `unit2` varchar(255) DEFAULT NULL,
  `qty2` varchar(255) DEFAULT NULL,
  `price2` varchar(255) DEFAULT NULL,
  `remarks2` varchar(255) DEFAULT NULL,
  `sno3` varchar(255) DEFAULT NULL,
  `item3` varchar(255) DEFAULT NULL,
  `unit3` varchar(255) DEFAULT NULL,
  `qty3` varchar(255) DEFAULT NULL,
  `price3` varchar(255) DEFAULT NULL,
  `remarks3` varchar(255) DEFAULT NULL,
  `sno4` varchar(255) DEFAULT NULL,
  `item4` varchar(255) DEFAULT NULL,
  `unit4` varchar(255) DEFAULT NULL,
  `qty4` varchar(255) DEFAULT NULL,
  `price4` varchar(255) DEFAULT NULL,
  `remarks4` varchar(255) DEFAULT NULL,
  `sno5` varchar(255) DEFAULT NULL,
  `item5` varchar(255) DEFAULT NULL,
  `unit5` varchar(255) DEFAULT NULL,
  `qty5` varchar(255) DEFAULT NULL,
  `price5` varchar(255) DEFAULT NULL,
  `remarks5` varchar(255) DEFAULT NULL,
  `sno6` varchar(255) DEFAULT NULL,
  `item6` varchar(255) DEFAULT NULL,
  `unit6` varchar(255) DEFAULT NULL,
  `qty6` varchar(255) DEFAULT NULL,
  `price6` varchar(255) DEFAULT NULL,
  `remarks6` varchar(255) DEFAULT NULL,
  `sno7` varchar(255) DEFAULT NULL,
  `item7` varchar(255) DEFAULT NULL,
  `unit7` varchar(255) DEFAULT NULL,
  `qty7` varchar(255) DEFAULT NULL,
  `price7` varchar(255) DEFAULT NULL,
  `remarks7` varchar(255) DEFAULT NULL,
  `sno8` varchar(255) DEFAULT NULL,
  `item8` varchar(255) DEFAULT NULL,
  `unit8` varchar(255) DEFAULT NULL,
  `qty8` varchar(255) DEFAULT NULL,
  `price8` varchar(255) DEFAULT NULL,
  `remarks8` varchar(255) DEFAULT NULL,
  `sno9` varchar(255) DEFAULT NULL,
  `item9` varchar(255) DEFAULT NULL,
  `unit9` varchar(255) DEFAULT NULL,
  `qty9` varchar(255) DEFAULT NULL,
  `price9` varchar(255) DEFAULT NULL,
  `remarks9` varchar(255) DEFAULT NULL,
  `sno0` varchar(255) DEFAULT NULL,
  `item0` varchar(255) DEFAULT NULL,
  `unit0` varchar(255) DEFAULT NULL,
  `qty0` varchar(255) DEFAULT NULL,
  `price0` varchar(255) DEFAULT NULL,
  `remarks0` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gpno` (`gpno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ow_gp_ret`
--


-- --------------------------------------------------------

--
-- Table structure for table `ow_non_main`
--

CREATE TABLE IF NOT EXISTS `ow_non_main` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ms` varchar(100) NOT NULL,
  `vehicle` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `time` time DEFAULT NULL,
  `depart` varchar(100) NOT NULL,
  `gpno` varchar(100) NOT NULL,
  `sender` varchar(100) NOT NULL,
  `approved` varchar(100) NOT NULL,
  `log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` varchar(16) NOT NULL,
  `address` text,
  `po_no` varchar(255) DEFAULT NULL,
  `return_date` varchar(256) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gpno` (`gpno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ow_non_main`
--


-- --------------------------------------------------------

--
-- Table structure for table `ow_non_sub`
--

CREATE TABLE IF NOT EXISTS `ow_non_sub` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gpno` varchar(100) NOT NULL,
  `item` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `ret_date` varchar(16) DEFAULT NULL COMMENT 'Not InUse',
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ow_non_sub`
--


-- --------------------------------------------------------

--
-- Table structure for table `ow_ret_main`
--

CREATE TABLE IF NOT EXISTS `ow_ret_main` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ms` varchar(100) NOT NULL,
  `vehicle` varchar(100) DEFAULT NULL,
  `date` date NOT NULL,
  `time` time DEFAULT NULL,
  `depart` varchar(100) NOT NULL,
  `gpno` varchar(100) NOT NULL,
  `sender` varchar(100) NOT NULL,
  `approved` varchar(100) NOT NULL,
  `return_date` date NOT NULL,
  `log` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` varchar(16) NOT NULL,
  `address` text,
  `po_no` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gpno` (`gpno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ow_ret_main`
--


-- --------------------------------------------------------

--
-- Table structure for table `ow_ret_sub`
--

CREATE TABLE IF NOT EXISTS `ow_ret_sub` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gpno` varchar(100) NOT NULL,
  `item` varchar(255) DEFAULT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `qty` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `remarks` varchar(255) DEFAULT NULL,
  `ret_date` varchar(255) DEFAULT 'No',
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `ow_ret_sub`
--


-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

CREATE TABLE IF NOT EXISTS `reg` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `reg`
--

INSERT INTO `reg` (`id`, `key`, `value`) VALUES
(1, 'clock', '18000');

-- --------------------------------------------------------

--
-- Table structure for table `unit`
--

CREATE TABLE IF NOT EXISTS `unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `unit`
--

INSERT INTO `unit` (`id`, `name`) VALUES
(4, 'KG'),
(2, 'MTR'),
(7, 'TON'),
(8, 'EA');

-- --------------------------------------------------------

--
-- Table structure for table `v`
--

CREATE TABLE IF NOT EXISTS `v` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `v`
--

INSERT INTO `v` (`id`, `name`) VALUES
(4, 'Jey Computers'),
(5, 'Rapid Computers'),
(8, 'BitStream');
